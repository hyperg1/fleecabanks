fx_version 'cerulean'
game 'gta5'

lua54 'yes'

this_is_a_map 'yes'

files {
    'audio/hypbank1_game.dat151.rel',
    'audio/hypbank2_game.dat151.rel',
    'audio/hypbank3_game.dat151.rel',
    'audio/hypbank4_game.dat151.rel',
    'audio/hypbank5_game.dat151.rel',
    'audio/hypbank6_game.dat151.rel'

}

data_file 'AUDIO_GAMEDATA' 'audio/hypbank1_game.dat'
data_file 'AUDIO_GAMEDATA' 'audio/hypbank2_game.dat'
data_file 'AUDIO_GAMEDATA' 'audio/hypbank3_game.dat'
data_file 'AUDIO_GAMEDATA' 'audio/hypbank4_game.dat'
data_file 'AUDIO_GAMEDATA' 'audio/hypbank5_game.dat'
data_file 'AUDIO_GAMEDATA' 'audio/hypbank6_game.dat'
dependency '/assetpacks'